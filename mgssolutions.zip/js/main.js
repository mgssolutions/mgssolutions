$('#owl-carousel').owlCarousel({
    loop: true,
    margin: 30,
    responsiveClass: true,
    responsive: {
        0: {
            items: 1,
        },
        600: {
            items: 1,
        },
        1000: {
            items: 1,
        }
    }

})






window.onclick = ()=>{
    //   console.log("heloo")
  

       setTimeout(()=>{
         //  console.log($('#collapsefaq2').hasClass('show'))
       if($('#collapsefaq1').hasClass('show')){
          
           $(`.collapsefaq1`).find("i.fa-solid").removeClass("fa-plus");
           $(`.collapsefaq1`).find("i.fa-solid").addClass("fa-minus");
       }else{
           
           $(`.collapsefaq1`).find("i.fa-solid").removeClass("fa-minus");
           $(`.collapsefaq1`).find("i.fa-solid").addClass("fa-plus");
       }

       if($('#collapsefaq2').hasClass('show')){
           $('.collapsefaq2').find("i.fa-solid").removeClass("fa-plus");
           $('.collapsefaq2').find("i.fa-solid").addClass("fa-minus");
       }else{
           $('.collapsefaq2').find("i.fa-solid").removeClass("fa-minus");
           $('.collapsefaq2').find("i.fa-solid").addClass("fa-plus");
       }

       if($('#collapsefaq3').hasClass('show')){
           $('.collapsefaq3').find("i.fa-solid").removeClass("fa-plus");
           $('.collapsefaq3').find("i.fa-solid").addClass("fa-minus");
       }else{
           $('.collapsefaq3').find("i.fa-solid").removeClass("fa-minus");
           $('.collapsefaq3').find("i.fa-solid").addClass("fa-plus");
       }

       if($('#collapsefaq4').hasClass('show')){
           $('.collapsefaq4').find("i.fa-solid").removeClass("fa-plus");
           $('.collapsefaq4').find("i.fa-solid").addClass("fa-minus");
       }else{
           $('.collapsefaq4').find("i.fa-solid").removeClass("fa-minus");
           $('.collapsefaq4').find("i.fa-solid").addClass("fa-plus");
       }

       if($('#collapsefaq5').hasClass('show')){
           $('.collapsefaq5').find("i.fa-solid").removeClass("fa-plus");
           $('.collapsefaq5').find("i.fa-solid").addClass("fa-minus");
       }else{
           $('.collapsefaq5').find("i.fa-solid").removeClass("fa-minus");
           $('.collapsefaq5').find("i.fa-solid").addClass("fa-plus");
       }

       if($('#collapsefaq6').hasClass('show')){
           $('.collapsefaq6').find("i.fa-solid").removeClass("fa-plus");
           $('.collapsefaq6').find("i.fa-solid").addClass("fa-minus");
       }else{
           $('.collapsefaq6').find("i.fa-solid").removeClass("fa-minus");
           $('.collapsefaq6').find("i.fa-solid").addClass("fa-plus");
       }

       if($('#collapsefaq7').hasClass('show')){
           $('.collapsefaq7').find("i.fa-solid").removeClass("fa-plus");
           $('.collapsefaq7').find("i.fa-solid").addClass("fa-minus");
       }else{
           $('.collapsefaq7').find("i.fa-solid").removeClass("fa-minus");
           $('.collapsefaq7').find("i.fa-solid").addClass("fa-plus");
       }

       if($('#collapsefaq8').hasClass('show')){
           $('.collapsefaq8').find("i.fa-solid").removeClass("fa-plus");
           $('.collapsefaq8').find("i.fa-solid").addClass("fa-minus");
       }else{
           $('.collapsefaq8').find("i.fa-solid").removeClass("fa-minus");
           $('.collapsefaq8').find("i.fa-solid").addClass("fa-plus");
       }

       if($('#collapsefaq9').hasClass('show')){
           $('.collapsefaq9').find("i.fa-solid").removeClass("fa-plus");
           $('.collapsefaq9').find("i.fa-solid").addClass("fa-minus");
       }else{
           $('.collapsefaq9').find("i.fa-solid").removeClass("fa-minus");
           $('.collapsefaq9').find("i.fa-solid").addClass("fa-plus");
       }

       if($('#collapsefaq10').hasClass('show')){
           $('.collapsefaq10').find("i.fa-solid").removeClass("fa-plus");
           $('.collapsefaq10').find("i.fa-solid").addClass("fa-minus");
       }else{
           $('.collapsefaq10').find("i.fa-solid").removeClass("fa-minus");
           $('.collapsefaq10').find("i.fa-solid").addClass("fa-plus");
       }

       if($('#collapsefaq11').hasClass('show')){
           $('.collapsefaq11').find("i.fa-solid").removeClass("fa-plus");
           $('.collapsefaq11').find("i.fa-solid").addClass("fa-minus");
       }else{
           $('.collapsefaq11').find("i.fa-solid").removeClass("fa-minus");
           $('.collapsefaq11').find("i.fa-solid").addClass("fa-plus");
       }

       if($('#collapsefaq12').hasClass('show')){
           $('.collapsefaq12').find("i.fa-solid").removeClass("fa-plus");
           $('.collapsefaq12').find("i.fa-solid").addClass("fa-minus");
       }else{
           $('.collapsefaq12').find("i.fa-solid").removeClass("fa-minus");
           $('.collapsefaq12').find("i.fa-solid").addClass("fa-plus");
       }

       if($('#collapsefaq13').hasClass('show')){
           $('.collapsefaq13').find("i.fa-solid").removeClass("fa-plus");
           $('.collapsefaq13').find("i.fa-solid").addClass("fa-minus");
       }else{
           $('.collapsefaq13').find("i.fa-solid").removeClass("fa-minus");
           $('.collapsefaq13').find("i.fa-solid").addClass("fa-plus");
       }

       if($('#collapsefaq14').hasClass('show')){
           $('.collapsefaq14').find("i.fa-solid").removeClass("fa-plus");
           $('.collapsefaq14').find("i.fa-solid").addClass("fa-minus");
       }else{
           $('.collapsefaq14').find("i.fa-solid").removeClass("fa-minus");
           $('.collapsefaq14').find("i.fa-solid").addClass("fa-plus");
       }

       if($('#collapsefaq15').hasClass('show')){
        $('.collapsefaq15').find("i.fa-solid").removeClass("fa-plus");
        $('.collapsefaq15').find("i.fa-solid").addClass("fa-minus");
    }else{
        $('.collapsefaq15').find("i.fa-solid").removeClass("fa-minus");
        $('.collapsefaq15').find("i.fa-solid").addClass("fa-plus");
    }




    if($('#collapsefaq16').hasClass('show')){
        $('.collapsefaq16').find("i.fa-solid").removeClass("fa-plus");
        $('.collapsefaq16').find("i.fa-solid").addClass("fa-minus");
    }else{
        $('.collapsefaq16').find("i.fa-solid").removeClass("fa-minus");
        $('.collapsefaq16').find("i.fa-solid").addClass("fa-plus");
    }


    if($('#collapsefaq17').hasClass('show')){
        $('.collapsefaq17').find("i.fa-solid").removeClass("fa-plus");
        $('.collapsefaq17').find("i.fa-solid").addClass("fa-minus");
    }else{
        $('.collapsefaq17').find("i.fa-solid").removeClass("fa-minus");
        $('.collapsefaq17').find("i.fa-solid").addClass("fa-plus");
    }


    if($('#collapsefaq18').hasClass('show')){
        $('.collapsefaq18').find("i.fa-solid").removeClass("fa-plus");
        $('.collapsefaq18').find("i.fa-solid").addClass("fa-minus");
    }else{
        $('.collapsefaq18').find("i.fa-solid").removeClass("fa-minus");
        $('.collapsefaq18').find("i.fa-solid").addClass("fa-plus");
    }


    if($('#collapsefaq19').hasClass('show')){
        $('.collapsefaq19').find("i.fa-solid").removeClass("fa-plus");
        $('.collapsefaq19').find("i.fa-solid").addClass("fa-minus");
    }else{
        $('.collapsefaq19').find("i.fa-solid").removeClass("fa-minus");
        $('.collapsefaq19').find("i.fa-solid").addClass("fa-plus");
    }


    if($('#collapsefaq20').hasClass('show')){
        $('.collapsefaq20').find("i.fa-solid").removeClass("fa-plus");
        $('.collapsefaq20').find("i.fa-solid").addClass("fa-minus");
    }else{
        $('.collapsefaq20').find("i.fa-solid").removeClass("fa-minus");
        $('.collapsefaq20').find("i.fa-solid").addClass("fa-plus");
    }

    
    if($('#collapsefaq21').hasClass('show')){
        $('.collapsefaq21').find("i.fa-solid").removeClass("fa-plus");
        $('.collapsefaq21').find("i.fa-solid").addClass("fa-minus");
    }else{
        $('.collapsefaq21').find("i.fa-solid").removeClass("fa-minus");
        $('.collapsefaq21').find("i.fa-solid").addClass("fa-plus");
    }

   },500)

   }


